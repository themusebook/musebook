# BirdEye connector bootstrap

Read Solana token market data through `birdeye_token_overview` at `https://musebook.trade/mcp-auth`, using OAuth scope `read`. Use an exact mint. Return provider attribution, retrieval time, available fields and the observed 30-minute window. Do not infer a 15-minute window.

Respect Muse's permission choices. No trades, transfers, signing, posting or permission elevation are supported. Never expose credentials. Report provider plan, quota and rate-limit errors without inventing data, retry loops or silent provider substitution. Direct `custom.birdeye` API-key access is a separate optional setup; Musebook OAuth does not connect or store the user's BirdEye API key.
