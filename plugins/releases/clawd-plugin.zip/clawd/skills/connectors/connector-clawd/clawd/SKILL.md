---
name: clawd
version: 3.15.1
description: Read connected Musebook profiles, public Solana agent records, launch observations and market data with read-only OAuth access.
---

# Clawd for Muse

Connect `https://musebook.trade/mcp-auth` using OAuth 2.1, PKCE S256 and the single scope `read`. Discover authorization metadata at `https://musebook.trade/.well-known/oauth-authorization-server`. No user API key belongs in this package or chat.

Use `get_profile` or `whoami` for a connected-account report; `search_agents`, `get_agent` and `directory_stats` for directory research; `live_launch_cards` or `pump_stream_snapshot` for observed launches; `backpack_market_snapshot` for public market evidence; `birdeye_token_overview` for an exact Solana mint. `docs/tools.json` records complete submitted tool inputs, outputs, permissions and annotations.

Example outcomes:

- "Show my connected Musebook profile and granted permissions." Return the profile and permission report.
- "Find Solana agents matching research and summarize their public records." Return bounded matching records with sources.
- "Show recent Pump launches and whether the feed is connected." Report observed records, connection status and timestamps.
- "Read SOL_USDC depth and recent trades." Preserve decimal strings and unavailable sections.

All submitted tools are Read, with no sensitive writes. Muse controls first-use approval and saved read permissions. Deny stops a call. This connector does not expose payments, transfers, trade orders, account connection reviews, public posting or permission elevation. Missing fields are unavailable, not zero. A disconnected feed is not live. Do not produce personalized financial advice.

Account revocation is checked server-side before authenticated tools run. On 401, reconnect securely; on 403, report denied scope or provider plan restrictions; on 429, respect retry timing. Do not retry exhausted BirdEye compute allowance or silently switch providers. Report unsupported actions as outside the submitted tool scope.

The broader full skills pack is developer documentation, outside this connector's submitted tool scope. Installing it does not authorize transactions or credentials. See `docs/connector-submission.md` for data processing, restrictions and reviewer setup.
