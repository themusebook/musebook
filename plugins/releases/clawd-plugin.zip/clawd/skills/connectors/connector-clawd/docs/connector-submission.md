# Clawd - Muse connector submission preparation

Prepared October 10, 2026. Version 3.15.1.

## Overview

Read-only Musebook account reports, public Solana agent discovery, observed launches and market research.

The structured information report completes the task and adds account access, provider data, source metadata and explicit availability beyond generic browser links. Example requests: Show my connected profile; find research agents; summarize recent launch observations and connection status.

Product: https://musebook.trade. Privacy: https://musebook.trade/privacy. Terms: https://musebook.trade/terms. Existing package contact: solanaclawd@agentmail.to; the owner must confirm this contact and business authority before submission. Musebook provider integration does not imply BirdEye affiliation or sponsorship.

## OAuth setup and permissions

Production MCP: https://musebook.trade/mcp-auth. OAuth 2.1 authorization code, PKCE S256, scope read only. Discovery: /.well-known/oauth-authorization-server and /.well-known/oauth-protected-resource/mcp-auth. Authorization: /oauth/authorize; token and revocation: /oauth/token; client registration: /oauth/register. Register the portal-provided redirect URI. Supply any client credentials through the secure portal process. No credentials belong in this archive.

Connecting an account authorizes only its consented read grant. Muse controls Allow once, Always allow and Deny. Read grants omit posting, account connection reviews, permission elevation, order preparation and wallet action tools. Other clients use the global authorization server's other scopes; these submissions request only read. BirdEye submits only birdeye_token_overview even though the shared endpoint exposes other read tools.

Tools, exact inputs/outputs, annotations, classification, sensitivity, side effects, errors and rate limits are documented in docs/tools.json. All submitted tools are Read and not sensitive. No purchases, payments, transfers or trade orders are supported. Provider failures return MCP isError. Missing fields are unavailable, not zero. A disconnected feed is not live. Never retry exhausted compute quota or silently substitute a provider.

## Data processing questionnaire

Account reports access the validated wallet identity, granted scopes, linked agent and an opaque credential identifier. Public tools read public directory, launch and market records. The BirdEye tool sends only the requested public mint to public-api.birdeye.so with a server-side provider credential. Optional custom.birdeye API-key use is a separate credential flow, not provided by Musebook OAuth.

HTTPS protects transport. Current account ownership, scope, expiry and revocation are checked before authenticated tools run. Provider keys and OAuth credentials are not returned. Third-party services receive only the request needed to answer the user's selected task. Routine service/provider access accounting may occur; no user account, wallet or order changes occur.

Before submission the owner must verify the privacy policy against actual storage encryption, user isolation, log retention, provider sharing, deletion procedures, and no secondary advertising, profiling or model-training use. Archive preparation cannot certify these operational claims. Revoking authorization stops authenticated access; retained-record deletion must follow the verified policy. No private reviewer data is included.

## Reviewer demo and intake

1. Provide a dedicated accessible Musebook test account and browser-wallet sign-in instructions through the portal. Never share a seed phrase or private key.
2. Connect the production endpoint with PKCE S256 and scope read; complete consent and a real callback into Muse.
3. Exercise every submitted tool, including denied calls, revocation, disconnected feeds, provider quota and plan failures. No real charges are required.
4. Check Read annotations and absent posting, account review and order/action tools for this grant.
5. Confirm business identity and submission authority, authorized brand assets, maintenance and support/security contacts, privacy/terms, retention/deletion answers and the 48-hour incident notification process required by the supplied guidelines.

Technical packaging is prepared. The dedicated reviewer account, complete live OAuth callback, business verification and operational privacy attestations still need the owner's setup. No portal submission or platform approval is claimed.
